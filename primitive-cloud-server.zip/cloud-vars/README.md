Cloud variables are stored in this folder as JSON files named after the project ID.
